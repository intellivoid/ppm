<?php declare(strict_types=1);

namespace PpmParser\Node;

use PpmParser\NodeAbstract;

abstract class Expr extends NodeAbstract
{
}
