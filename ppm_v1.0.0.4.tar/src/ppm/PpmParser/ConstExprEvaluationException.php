<?php

namespace PpmParser;

use Exception;

class ConstExprEvaluationException extends Exception
{}
