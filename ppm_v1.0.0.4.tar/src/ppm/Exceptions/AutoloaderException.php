<?php


    namespace ppm\Exceptions;


    use Exception;

    /**
     * Class AutoloaderException
     * @package ppm\Exceptions
     */
    class AutoloaderException extends Exception
    {
    }