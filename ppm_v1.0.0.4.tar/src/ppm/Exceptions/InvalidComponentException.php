<?php


    namespace ppm\Exceptions;


    use Exception;

    /**
     * Class InvalidComponentException
     * @package ppm\Exceptions
     */
    class InvalidComponentException extends Exception
    {
    }