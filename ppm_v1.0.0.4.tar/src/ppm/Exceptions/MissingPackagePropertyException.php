<?php


    namespace ppm\Exceptions;


    use Exception;

    /**
     * Class MissingPackagePropertyException
     * @package ppm\Exceptions
     */
    class MissingPackagePropertyException extends Exception
    {
    }