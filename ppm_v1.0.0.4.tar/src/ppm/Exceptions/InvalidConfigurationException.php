<?php


    namespace ppm\Exceptions;


    use Exception;

    /**
     * Class InvalidConfigurationException
     * @package ppm\Exceptions
     */
    class InvalidConfigurationException extends Exception
    {
    }