<?php


    namespace ppm\Exceptions;


    use Exception;

    class InvalidPackageException extends Exception
    {
    }