<?php


    namespace ppm\Exceptions;


    use Exception;

    /**
     * Class PackageNotFoundException
     * @package ppm\Exceptions
     */
    class PackageNotFoundException extends Exception
    {
    }