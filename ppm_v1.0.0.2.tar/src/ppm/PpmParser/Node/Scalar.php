<?php declare(strict_types=1);

namespace PpmParser\Node;

abstract class Scalar extends Expr
{
}
