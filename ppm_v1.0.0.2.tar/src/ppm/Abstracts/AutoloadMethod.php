<?php


    namespace ppm\Abstracts;


    abstract class AutoloadMethod
    {
        const Static = "static";

        const Indexed = "indexed";
    }