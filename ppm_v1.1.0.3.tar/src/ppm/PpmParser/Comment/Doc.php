<?php declare(strict_types=1);

    namespace PpmParser\Comment;

    use PpmParser\Comment;

    /**
     * Class Doc
     * @package PpmParser\Comment
     */
    class Doc extends Comment
    {
    }
