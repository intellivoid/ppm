<?php


    namespace ppm\Exceptions;


    use Exception;

    /**
     * Class PathNotFoundException
     * @package ppm\Exceptions
     */
    class PathNotFoundException extends Exception
    {
    }