<?php


    namespace ppm\Exceptions;


    use Exception;

    /**
     * Class CacheException
     * @package ppm\Exceptions
     */
    class CacheException extends Exception
    {

    }