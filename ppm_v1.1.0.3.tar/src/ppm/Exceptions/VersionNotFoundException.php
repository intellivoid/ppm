<?php


    namespace ppm\Exceptions;


    use Exception;

    /**
     * Class VersionNotFoundException
     * @package ppm\Exceptions
     */
    class VersionNotFoundException extends Exception
    {
    }