<?php


    namespace ppm\Exceptions;


    use Exception;

    /**
     * Class InvalidPackageLockException
     * @package ppm\Exceptions
     */
    class InvalidPackageLockException extends Exception
    {
    }