<?php


    namespace ppm\Exceptions;


    use Exception;

    /**
     * Class InvalidDependencyException
     * @package ppm\Exceptions
     */
    class InvalidDependencyException extends Exception
    {
    }